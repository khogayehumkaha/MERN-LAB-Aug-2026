<div align="center">

# 🚀 ISE – 5th SEM MERN LAB PROGRAMS
### PART-A : `1, 2, 3, 4, 9` &nbsp;|&nbsp; PART-B : `5, 6, 7, 8, 10`

![Node.js](https://img.shields.io/badge/Node.js-LTS-339933?logo=nodedotjs&logoColor=white)
![Express](https://img.shields.io/badge/Express-5.x-000000?logo=express&logoColor=white)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-pg-4169E1?logo=postgresql&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-Mongoose-47A248?logo=mongodb&logoColor=white)
![JWT](https://img.shields.io/badge/Auth-JWT-000000?logo=jsonwebtokens&logoColor=white)

**Every program comes with: 📝 Problem · 🧾 Code · ▶️ Run · 🧪 Test (Browser / curl / Postman) · ✅ Expected output · 💡 How it works · 🎓  Q&A**

</div>

---

> 💡 **Simpler, optimized codes** are named as `ProgramName-Simple.js`.

## 📚 Program Index

| Part | # | Aim | File | Endpoints | Needs |
|------|---|-----|------|-----------|-------|
| A | [1](#p1) | HTTP server with URL routing | `1.HttpServer.js` | `/`, `/about`, other → 404 | Node |
| A | [2](#p2) | Server returning HTML tags | `2.HTMLserver.js` | `/`, `/about` | Node |
| A | [3](#p3) | Static file server (HTML/CSS/JS) | `3.StaticServer.js` | `/`, `/style.css`, `/script.js` | Node |
| A | [4](#p4) | Read/write JSON objects in a file | `4.JSON-RW.js` | `GET/POST /items` | Node |
| A | [9](#p9) | Express global middleware + log file | `9.Middleware.js` | `/`, `/about` | Express |
| B | [5](#p5) | CRUD REST API using an **array** | `5.CRUD-Array.js` | `/product` (GET, POST, PUT, DELETE) | Express |
| B | [6](#p6) | CRUD REST API using a **file** | `6.CRUD-File.js` | `/product` (GET, POST, PUT, DELETE) | Express |
| B | [7](#p7) | CRUD REST API with **PostgreSQL** | `7.CRUD-PSQL.js` + `pgdb.js` | `/users` (GET, POST, PUT, DELETE) | Express, pg, PostgreSQL |
| B | [8](#p8) | CRUD REST API with **MongoDB** | `8.CRUD-Mongo.js` | `/users` (GET, POST, PUT, DELETE) | Express, mongoose, MongoDB |
| B | [10](#p10) | **JWT** authentication | `10.WebToken.js` + `pgdb.js` | `POST /signup`, `POST /login`, `GET /home` | Express, jsonwebtoken, bcrypt, pg |
| – | [🎓](#Q&A) | **Basic & Program-Specific Q&A** | – | All 10 Programs + MERN Concepts | – |

---

## ⚙️ Setup (do this once)

### 🧰 Tools you need

| Tool | Used for | Programs |
|------|----------|----------|
| [Node.js (LTS)](https://nodejs.org) | running every program | all |
| [Postman](https://www.postman.com/downloads/) | testing POST / PUT / DELETE | 4 – 10 |
| PostgreSQL + pgAdmin | database | 7, 10 |
| MongoDB Community Server (+ Compass) | database | 8 |

### 📦 Install the packages

```bash
mkdir mern-lab && cd mern-lab
npm init -y
npm install express pg mongoose jsonwebtoken bcrypt
```

Programs 1–4 use only Node's built-in modules (`http`, `fs`, `path`), so they need no packages.

### ▶️ Run a program

```bash
node 1.HttpServer.js
```

Stop the server with **Ctrl + C**. After you edit the code, stop and start it again.

> ⚠️ **Every program listens on port `3000`.** Run only **one server at a time**. If you see `Error: listen EADDRINUSE :::3000`, an earlier server is still running – stop it first.

### 🗂️ Repository structure

```text
.
├── README.md
├── ISELab-Programs/            # simpler versions: ProgramName-Simple.js
│
├── 1.HttpServer.js             # PART-A
├── 2.HTMLserver.js
├── 3.StaticServer.js           #   + index.html, style.css, script.js
├── 4.JSON-RW.js                #   creates data.json automatically
├── 9.Middleware.js             #   creates requests.log automatically
│
├── 5.CRUD-Array.js             # PART-B
├── 6.CRUD-File.js              #   creates product.json automatically
├── 7.CRUD-PSQL.js              #   uses pgdb.js
├── 8.CRUD-Mongo.js
├── 10.WebToken.js              #   uses pgdb.js
└── pgdb.js                     # PostgreSQL connection (shared by 7 and 10)
```

---

<a id="p1"></a>
# 🔐 Problem 1:
Create a simple Node.js HTTP server that listens on port 3000 and routes requests based on the URL path. The server should handle the following:

- `/` returns "Welcome to the homepage!"
- `/about` returns "This is the about page."
- Any other URL should return "Page not found" with a 404 status.

---

## 🧾 1.HttpServer.js

```javascript
const http = require("http");

const server = http.createServer((req, res) => {
    res.setHeader("Content-Type", "text/plain");
    if (req.url === "/") {
        res.statusCode = 200;
        res.end("Welcome to the homepage!");
    } else if (req.url === "/about") {
        res.statusCode = 200;
        res.end("This is the about page.");
    } else {
        res.statusCode = 404;
        res.end("Page not found");
    }
});

server.listen(3000, () => {
    console.log(`Server running at http://localhost:3000`);
});
```

## ▶️ : Run the Server

```bash
node 1.HttpServer.js
```

## 🌐 Access the Server

Open your browser or use curl/Postman:

- [http://localhost:3000/](http://localhost:3000/)
- [http://localhost:3000/about](http://localhost:3000/about)
- [http://localhost:3000/invalid](http://localhost:3000/invalid)

## ✅ Expected Output

| URL | Status | Response |
|-----|--------|----------|
| `/` | `200 OK` | `Welcome to the homepage!` |
| `/about` | `200 OK` | `This is the about page.` |
| `/invalid` | `404 Not Found` | `Page not found` |

## 💡 How it works

- `http.createServer((req, res) => …)` runs the callback for **every request**.
- `req.url` holds the path; an `if / else if / else` chain **routes** it.
- `res.statusCode` sets the HTTP status and `res.end(text)` sends the body and finishes the response.


---
---

<a id="p2"></a>
# 🔐 Problem 2:
Create a Node.js server to integrate HTML tags and code directly within server-side handlers.

---

## 🧾 2.HTMLserver.js

```javascript
const http = require("http");

const server = http.createServer((req, res) => {
    res.setHeader("Content-Type", "text/html");
    if (req.url === "/") {
        res.statusCode = 200;
        res.write("<h1>Welcome to Node.js Server</h1>");
        res.write("<p>This is a simple server with HTML content.</p>");
        res.end();
    } else if (req.url === "/about") {
        res.statusCode = 200;
        res.end("<h1>This is the about page.</h1>");
    } else {
        res.statusCode = 404;
        res.end("<h1>Page not found</h1>");
    }
});

server.listen(3000, () => {
    console.log(`Server running at http://localhost:3000`);
});
```

## ▶️ : Run the Server

```bash
node 2.HTMLserver.js
```

## 🌐 Access the Server

- [http://localhost:3000/](http://localhost:3000/) → shows a heading and a paragraph
- [http://localhost:3000/about](http://localhost:3000/about) → `This is the about page.`
- [http://localhost:3000/invalid](http://localhost:3000/invalid) → `404` (`Page not found`)

## ✅ Expected Output

The browser **renders** the HTML at `/`: a large heading **Welcome to Node.js Server** followed by the paragraph *This is a simple server with HTML content.*

## 💡 How it works

- The only change from Problem 1 is the header: `Content-Type: text/html` tells the browser to **render** the text as HTML instead of showing the raw tags.
- `res.write()` can be called many times; `res.end()` finishes the response.


---
---

<a id="p3"></a>
# 🔐 Problem 3:
Create a Node.js server that serves static files (HTML, CSS, JS) from the current directory. The server should return a proper 404 status code if the requested file doesn't exist.

---

## 🧾 3.StaticServer.js

```javascript
//(Place files: index.html, style.css, script.js in same folder)

const http = require("http");
const fs = require("fs").promises;
const path = require("path");

const mimes = { 
    ".html": "text/html", 
    ".css": "text/css", 
    ".js": "text/javascript" 
};

const server = http.createServer(async (req, res) => {
    const file = path.join(__dirname, req.url === "/" ? "index.html" : req.url);
    try {
        const data = await fs.readFile(file);
        res.writeHead(200, { "Content-Type": mimes[path.extname(file)] || "text/plain" });
        res.end(data);
    } catch {
        res.writeHead(404, { "Content-Type": "text/plain" });
        res.end("404 File Not Found");
    }
});

server.listen(3000, () => {
    console.log(`Server running at http://localhost:3000`);
});
```

## 🧾 index.html

```html
<!DOCTYPE html>
<html>
<head>
  <title>Node Static Server</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>Hello from index.html </h1>
  <script src="script.js"></script>
</body>
</html>
```

## 🧾 style.css

```css
body {
    background-color: orange;
    font-family: Arial;
  }
```

## 🧾 script.js

```javascript
console.log("Hello from script.js!");
```

> 📁 Place `index.html`, `style.css` and `script.js` in the **same folder** as `3.StaticServer.js`.

## ▶️ : Run the Server

```bash
node 3.StaticServer.js
```

## 🌐 Access the Server

- [http://localhost:3000/](http://localhost:3000/) → `index.html`
- [http://localhost:3000/style.css](http://localhost:3000/style.css)
- [http://localhost:3000/script.js](http://localhost:3000/script.js)
- [http://localhost:3000/missing.html](http://localhost:3000/missing.html) → `404 File Not Found`

## ✅ Expected Output

| URL | Status | Content-Type |
|-----|--------|--------------|
| `/` | `200` | `text/html` – page with an **orange** background and the heading *Hello from index.html used by File Server* |
| `/style.css` | `200` | `text/css` |
| `/script.js` | `200` | `application/javascript` |
| `/missing.html` | `404` | `text/plain` – `404 File Not Found` |

Open the browser console (**F12 → Console**) to see `Hello from script.js!`.

## 💡 How it works

- `/` is mapped to `index.html`; any other URL is joined to the current folder with `path.join(__dirname, req.url)`.
- `path.extname()` finds the extension and the `mimeTypes` object picks the matching `Content-Type`.
- `fs.readFile` returns an error if the file does not exist → the server sends **404**.


---
---

<a id="p4"></a>
# 🔐 Problem 4:
Create a Node.js server to read and write JSON objects using files to save the JSON objects.

---

## 🧾 4.JSON-RW.js

```javascript
const http = require("http");
const fs = require("fs");

const FILE = "data.json";

function readData() {
    if (!fs.existsSync(FILE)) return [];
    return JSON.parse(fs.readFileSync(FILE, "utf-8") || "[]");
}

function writeData(data) {
    fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

const server = http.createServer((req, res) => {
    res.setHeader("Content-Type", "application/json");
    if (req.url === "/items" && req.method === "GET") {
        res.end(JSON.stringify(readData()));
    }
    else if (req.url === "/items" && req.method === "POST") {
        let body = "";
        req.on("data", chunk => body += chunk);
        req.on("end", () => {
            const item = JSON.parse(body);
            const data = readData();
            data.push(item);
            writeData(data);
            res.statusCode = 201;
            res.end("Item added successfully");
        });
    }
    else {
        res.statusCode = 404;
        res.end("Error PAGE NOT FOUND");
    }
});

server.listen(3000, () => {
    console.log("Server running at http://localhost:3000/items");
});
```

## ▶️ : Run the Server

```bash
node 4.JSON-RW.js
```

## 🧪 Test in POSTMAN

| Method | URL | Body |
|--------|-----|------|
| `GET` | `http://localhost:3000/items` | none |
| `POST` | `http://localhost:3000/items` | `raw` + `JSON` |

### 1️⃣ Get all items

- Method: `GET` &nbsp;·&nbsp; URL: `http://localhost:3000/items` &nbsp;·&nbsp; Body: not needed

**Response** *(nothing has been added yet, so we get an empty array)*
```json
[]
```

### 2️⃣ Add a new item

- Method: `POST` &nbsp;·&nbsp; URL: `http://localhost:3000/items`
- Body → select **raw** → **JSON** and paste:

```json
{
  "name": "Pen",
  "price": 10
}
```

**Response** — status `201 Created` *(plain text)*
```text
Item added successfully
```

### 3️⃣ Verify

Send `GET /items` again. This time you get the item you added, and it is saved in **`data.json`** (the file is created automatically):

```json
[
    {
        "name": "Pen",
        "price": 10
    }
]
```

### 💻 Same thing with curl *(Linux / macOS / Git Bash)*

```bash
curl http://localhost:3000/items
curl -X POST http://localhost:3000/items -H "Content-Type: application/json" -d '{"name":"Pen","price":10}'
curl http://localhost:3000/items
```

> Any other URL or method returns `404` with `Issue While Adding Item`.

## 💡 How it works

- `readData()` returns the array stored in `data.json` (or `[]` if the file doesn't exist yet); `writeData()` saves it back with `JSON.stringify(data, null, 2)`.
- A POST body arrives in **chunks**: `req.on("data")` collects them and `req.on("end")` parses the JSON, pushes it to the array and writes the file.


---
---

<a id="p9"></a>
# 🔐 Problem 9:
Create a Node.js application using Express.js with global middleware to log all incoming requests in a log file (`requests.log`).

---

## 🧾 9.Middleware.js

```javascript
const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();

const logFile = "requests.log";

app.use((req, res, next) => {
    const logMessage = `${req.method} ${req.url}\n`;
    console.log(logMessage);
    fs.appendFileSync(logFile, logMessage);
    next();
});

function aboutMiddleware(req, res, next) {
    console.log("Accessed /about");
    next();
}

app.get("/", (req, res) => {
    res.send("Welcome to Home Page");
});

app.get("/about", aboutMiddleware, (req, res) => {
    res.send("This is About Page");
});

app.use((req, res) => {
    res.status(404).send("404 Page Not Found");
});

app.listen(3000, () => {
    console.log(`Server running at http://localhost:3000`);
});
```

## ▶️ : Run the Server

```bash
node 9.Middleware.js
```

## 🌐 Access the Server

- [http://localhost:3000/](http://localhost:3000/)
- [http://localhost:3000/about](http://localhost:3000/about)
- [http://localhost:3000/other](http://localhost:3000/other)

## ✅ Expected Output

| URL | Status | Response |
|-----|--------|----------|
| `/` | `200` | `Welcome to Home Page` |
| `/about` | `200` | `This is About Page` *(terminal also prints `Accessed /about`)* |
| `/other` | `404` | `404 Page Not Found` |

**`requests.log`** (created next to the program) after visiting the three URLs:

```text
GET /
GET /about
GET /other
```

> 🔎 Browsers may also request `/favicon.ico`, so you can see an extra `GET /favicon.ico` line.

## 💡 How it works

- `app.use((req, res, next) => …)` registered **first** is a **global middleware**: it runs for every request, appends `METHOD URL` to the log with `fs.appendFileSync`, then calls `next()` to pass control on.
- `aboutMiddleware` is a **route-level middleware** – it runs only for `/about`.
- The last `app.use` has no path, so it catches every unmatched URL → **404**. Order matters: it must come after all routes.


---
---

<a id="p5"></a>
# 🔐 Problem 5:
Create a REST API using Express.js. The API should support the following CRUD operations for managing items (using arrays). An item has `name`, `description`, `price` fields:

- a. `GET /items`: Return a list of all items.
- b. `POST /items`: Add a new item to the list.
- c. `PUT /items/:id`: Update an item by ID.
- d. `DELETE /items/:id`: Delete an item by ID.

> 📝 In the code below the resource is named **`/product`** instead of `/items`.

---

## 🧾 5.CRUD-Array.js

```javascript
const express = require("express");
const app = express();
app.use(express.json());

let items = [];
let id = 1;

// GET all
app.get("/product", (req, res) => res.json(items));

// POST add
app.post("/product", (req, res) => {
    const new_item = { id: id++, ...req.body };
    items.push(new_item);
    res.json(new_item);
});

// PUT update
app.put("/product/:id", (req, res) => {
    const index = items.findIndex(i => i.id == req.params.id);
    if (index < 0) return res.send("Item not found");

    items[index] = { id: Number(req.params.id), ...req.body };
    res.send("Updated Successfully");
});

// DELETE delete
app.delete("/product/:id", (req, res) => {
    const index = items.findIndex(i => i.id == req.params.id);
    if (index < 0) return res.send("Item not found");

    items.splice(index, 1);
    res.send("Deleted successfully");
});

app.listen(3000, () => {
    console.log(`Server running at http://localhost:3000`);
});
```

## ▶️ : Run the Server

```bash
node 5.CRUD-Array.js
```

## 🔗 Endpoints

| Operation | Method | URL | Body |
|-----------|--------|-----|------|
| Create | `POST` | `/product` | `name`, `description`, `price` |
| Read | `GET` | `/product` | – |
| Update | `PUT` | `/product/:id` | `name`, `description`, `price` |
| Delete | `DELETE` | `/product/:id` | – |

## 🧪 Test in POSTMAN

### 1️⃣ Get all products

- Method: `GET` &nbsp;·&nbsp; URL: `http://localhost:3000/product` &nbsp;·&nbsp; Body: not needed

**Response** — initially an empty array, as nothing has been added yet
```json
[]
```

### 2️⃣ Add a new product

- Method: `POST` &nbsp;·&nbsp; URL: `http://localhost:3000/product`
- Body → **raw** → **JSON**:

```json
{
  "name": "Pen",
  "description": "Ball Pen",
  "price": 10
}
```

**Response**
```json
{
    "id": 1,
    "name": "Pen",
    "description": "Ball Pen",
    "price": 10
}
```

Send `GET /product` again – now you get this product instead of `[]`.

### 3️⃣ Update a product

Suppose you gave a wrong product name. Use `PUT` with the product **id** at the end of the URL.

- Method: `PUT` &nbsp;·&nbsp; URL: `http://localhost:3000/product/1`
- ⚠️ Do not forget the `/1` (the id of the product to update) – otherwise you get `404 Not Found`.
- Body:

```json
{
  "name": "Black Rock Pen",
  "description": "Black ink pen",
  "price": 12
}
```

**Response** *(plain text)*
```text
Updated Successfully
```

Check with `GET /product`:
```json
[
    {
        "id": 1,
        "name": "Black Rock Pen",
        "description": "Black ink pen",
        "price": 12
    }
]
```

### 4️⃣ Delete a product

Production of the *Black Rock Pen* has stopped, so delete it.

- Method: `DELETE` &nbsp;·&nbsp; URL: `http://localhost:3000/product/1`

**Response** *(plain text)*
```text
Deleted Successfully
```

If the id does not exist, `PUT` and `DELETE` respond with `Item not found`.

### 💻 Same thing with curl *(Linux / macOS / Git Bash)*

```bash
curl http://localhost:3000/product
curl -X POST   http://localhost:3000/product   -H "Content-Type: application/json" -d '{"name":"Pen","description":"Ball Pen","price":10}'
curl -X PUT    http://localhost:3000/product/1 -H "Content-Type: application/json" -d '{"name":"Black Rock Pen","description":"Black ink pen","price":12}'
curl -X DELETE http://localhost:3000/product/1
```

## 💡 How it works

- `app.use(express.json())` parses a JSON request body into `req.body`.
- Items live in the `items` **array**; `id_counter++` gives each new item a unique id.
- `findIndex` locates the item by id (`req.params.id` is a string, so `parseInt` is used); `splice` removes it.
- ⚠️ Data is stored **in memory only** – it disappears when the server restarts (Problem 6 fixes this by using a file).


---
---

<a id="p6"></a>
# 🔐 Problem 6:
Create a REST API using Express.js. The API should support the above (as in Q.no 5) CRUD operations for managing items using files (save items in `products.json`). An item has `name`, `description`, `price` fields.

---

## 🧾 6.CRUD-File.js

```javascript
const express = require("express");
const fs = require("fs");
const app = express();
app.use(express.json());

const FILE = "products.json";

function read() {
    if (fs.existsSync(FILE)) {
        return JSON.parse(fs.readFileSync(FILE, "utf-8") || "[]");
    } else {
        return { counter: 0, items: [] };
    }
}

function write(data) {
    fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

// CREATE
app.post("/product", (req, res) => {
    const data = read();
    const new_item = { id: ++data.counter, ...req.body };
    data.items.push(new_item);
    write(data);
    res.json(new_item);
});

// DISPLAY ALL
app.get("/product", (req, res) => {
    res.json(read().items);
});

// UPDATE
app.put("/product/:id", (req, res) => {
    const data = read();
    const index = data.items.findIndex(i => i.id == req.params.id);
    if (index < 0) return res.send("Item not found");

    data.items[index] = { id: Number(req.params.id), ...req.body };
    write(data);
    res.send("Updated Successfully");
});

// DELETE
app.delete("/product/:id", (req, res) => {
    const data = read();
    const index = data.items.findIndex(i => i.id == req.params.id);
    if (index < 0) return res.send("Item not found");

    data.items.splice(index, 1);
    write(data);
     res.send("Deleted Successfully");
});

app.listen(3000,()=>{
    console.log(`Server running at http://localhost:3000`);
});
```

## ▶️ : Run the Server

```bash
node 6.CRUD-File.js
```

## 🧪 Test in POSTMAN

The requests and responses are **exactly the same as Problem 5**:

| Operation | Method | URL | Body | Response |
|-----------|--------|-----|------|----------|
| Read | `GET` | `/product` | – | `[]` at first, then the list of items |
| Create | `POST` | `/product` | `{"name":"Pen","description":"Ball Pen","price":10}` | `{"id":1,"name":"Pen","description":"Ball Pen","price":10}` |
| Update | `PUT` | `/product/1` | `{"name":"Black Rock Pen","description":"Black ink pen","price":12}` | `Updated Successfully` |
| Delete | `DELETE` | `/product/1` | – | `Deleted Successfully` |

(Wrong id → `Item not found`.)

### 📄 What is saved in the file

After the POST and PUT above, **`product.json`** (created automatically) contains:

```json
{"counter":1,"items":[{"id":1,"name":"Black Rock Pen","description":"Black ink pen","price":12}]}
```

After the DELETE, the item is removed but the counter is kept, so the next product gets id `2` and ids are never reused:

```json
{"counter":1,"items":[]}
```

✅ **Stop and restart the server** and `GET /product` still returns your data – that is the difference from Problem 5.

## 💡 How it works

- `read()` loads `product.json` (or starts with `{ counter: 0, items: [] }`); `write()` saves the whole object back.
- Every operation is **read → change → write**.
- `counter` is stored in the file together with the items, so ids stay unique across restarts.


---
---

<a id="p7"></a>
# 🔐 Problem 7:
Create a simple REST API using Express.js and PostgreSQL that allows users to interact with a database. The API should support the following actions:

- a. **Create:** Add a new user to the database.
- b. **Read:** Retrieve all users from the database.
- c. **Update:** Update a user's information in the database.
- d. **Delete:** Delete a user from the database.

The database will store basic user information such as `id`, `name`, and `email`.

---

## 🗃️ Step 1: PostgreSQL Table Creation

Use **pgAdmin** to create a database with a name of your choice (here `MyDB`). Inside it, run this SQL in the **Query Tool** to create the `users` table:

```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);
```

## 🧾 Step 2: pgdb.js *(database connection)*

```javascript
const { Pool } = require('pg');
const pool = new Pool({
    user: 'postgres',
    password: 'admin',
    host: 'localhost',
    port: '5432',
    database: 'MyDB',
});
module.exports = pool;
```

> ⚠️ Change `user`, `password` and `database` to match **your** PostgreSQL installation (the password is the one you set while installing PostgreSQL).

## 🧾 Step 3: 7.CRUD-PSQL.js

```javascript
const express = require("express");
const pool = require("./pgdb");
const app = express();
app.use(express.json());

// CREATE
app.post("/users", async (req, res) => {
    const { name, email } = req.body;
    const result = await pool.query("INSERT INTO users (name, email) VALUES ($1, $2) RETURNING *", [name, email]);
    if (result.rows.length === 0) return res.send("Row Not Found");
    res.send("Row Added");
});

// READ
app.get("/users", async (req, res) => {
    const result = await pool.query("SELECT * FROM users");
    if (result.rows.length === 0) return res.send("Row Not Found");
    res.send(result.rows);
});

// UPDATE
app.put("/users/:id", async (req, res) => {
    const id = req.params.id;
    const { name, email } = req.body;
    const result = await pool.query("UPDATE users SET name=$1, email=$2 WHERE id=$3 RETURNING *", [name, email, id]);
    if (result.rows.length === 0) return res.send("Row Not Found");
    res.send("Row Updated");
});

// DELETE
app.delete("/users/:id", async (req, res) => {
    const id = req.params.id;
    const result = await pool.query("DELETE FROM users WHERE id=$1 RETURNING *", [id]);
    if (result.rows.length === 0) return res.send("Row Not Found");
    res.send("Row Deleted");
});

app.listen(3000, () => {
    console.log(`Server running at http://localhost:3000`);
});
```

## ▶️ : Run the Server

```bash
node 7.CRUD-PSQL.js
```

## 🔗 Endpoints

| Operation | Method | URL | Body |
|-----------|--------|-----|------|
| Create | `POST` | `/users` | `name`, `email` |
| Read | `GET` | `/users` | – |
| Update | `PUT` | `/users/:id` | `name`, `email` |
| Delete | `DELETE` | `/users/:id` | – |

## ✅ Test with Postman

### 1️⃣ Create User

- Method: `POST` &nbsp;·&nbsp; URL: `http://localhost:3000/users`
- Body → **raw** → **JSON**:

```json
{
    "name": "Vaikunt Pai",
    "email": "vaiku@example.com"
}
```

**Response** *(plain text)*
```text
Row Added
```

### 2️⃣ Get All Users

- Method: `GET` &nbsp;·&nbsp; URL: `http://localhost:3000/users` &nbsp;·&nbsp; Body: not needed

**Response** *(list of all rows in the `users` table; if empty, returns `Row Not Found`)*
```json
[
    {
        "id": 1,
        "name": "Vaikunt Pai",
        "email": "vaiku@example.com"
    }
]
```

### 3️⃣ Update User

- Method: `PUT` &nbsp;·&nbsp; URL: `http://localhost:3000/users/1` &nbsp;*(`1` = id of the user to update)*
- Body:

```json
{
    "name": "Vaikunt Pai Nitte",
    "email": "vaikunt@example.com"
}
```

**Response** *(plain text)*
```text
Row Updated
```

*(Calling `GET /users` now shows the updated name and email.)*

### 4️⃣ Delete User

- Method: `DELETE` &nbsp;·&nbsp; URL: `http://localhost:3000/users/1` &nbsp;*(id of the user to delete)* &nbsp;·&nbsp; Body: not needed

**Response** *(plain text)*
```text
Row Deleted
```

An `id` that does not exist returns `Row Not Found`.

## 💡 How it works

- `pg`'s `Pool` manages database connections; `pool.query(sql, [values])` executes SQL queries.
- `$1, $2, $3` are **parameterized placeholders** – values are passed separately, which protects against SQL injection.
- `RETURNING *` returns the affected rows so `result.rows.length` can confirm whether a row was inserted, updated, or deleted.
- `email` is `UNIQUE`: inserting the same email twice makes the query fail, so use a different email for each user.


---
---

<a id="p8"></a>
# 🔐 Problem 8:
Create a simple REST API using Express.js, MongoDB and Mongoose that allows users to interact with a database. The API should support the following actions:

- a. **Create:** Add a new user to the database.
- b. **Read:** Retrieve all users from the database.
- c. **Update:** Update a user's information in the database (document id).
- d. **Delete:** Delete a user from the database (document id).

The database will store basic user information such as `id`, `name`, and `email`.

---

## 🗃️ Before you start

Make sure the **MongoDB server is running** on the default port `27017`. The code connects to `mongodb://localhost:27017/TestDB`. The database and collection are created automatically on the first insert; you can view the data in **MongoDB Compass**.

## 🧾 8.CRUD-Mongo.js

```javascript
const express = require("express");
const mongoose = require("mongoose");
const app = express();
app.use(express.json());

async function connectdb() {
    await mongoose.connect("mongodb://localhost:27017/TestDB");
    console.log("Connected to mongodb");
}
connectdb();

// Schema (Flexible)
const User = mongoose.model("User", new mongoose.Schema({}, { strict: false }));

// CREATE
app.post("/users", async (req, res) => {
    const result = await User.create(req.body);
    res.send(result);
});

// READ
app.get("/users", async (req, res) => {
    const result = await User.find();
    res.send(result);
});

// UPDATE
app.put("/users/:id", async (req, res) => {
    const result = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.send(result);
});

// DELETE
app.delete("/users/:id", async (req, res) => {
    const result = await User.findByIdAndDelete(req.params.id);
    res.send(result);
});

app.listen(3000, () => {
      console.log(`Server running at http://localhost:3000`);
});
```

## ▶️ : Run the Server

```bash
node 8.CRUD-Mongo.js
```

The terminal prints `Server running at http://localhost:3000` and `Connected to mongodb`.

## 🔗 Endpoints

| Operation | Method | URL | Body |
|-----------|--------|-----|------|
| Create | `POST` | `/users` | `name`, `email` |
| Read | `GET` | `/users` | – |
| Update | `PUT` | `/users/:id` | fields to change |
| Delete | `DELETE` | `/users/:id` | – |

## ✅ Test with Postman

### 1️⃣ Create User

- Method: `POST` &nbsp;·&nbsp; URL: `http://localhost:3000/users`
- Body → **raw** → **JSON**:

```json
{
    "name": "Vaikunt Pai",
    "email": "vaiku@example.com"
}
```

**Response**
```json
{
    "name": "Vaikunt Pai",
    "email": "vaiku@example.com",
    "_id": "684f0eff17abc4e41f7cc459",
    "__v": 0
}
```

> `_id` and `__v` are generated automatically by MongoDB / Mongoose. **Copy the `_id`** – you need it for update and delete.

### 2️⃣ Get All Users

- Method: `GET` &nbsp;·&nbsp; URL: `http://localhost:3000/users` &nbsp;·&nbsp; Body: not needed

**Response**
```json
[
    {
        "_id": "684f0eff17abc4e41f7cc459",
        "name": "Vaikunt Pai",
        "email": "vaiku@example.com",
        "__v": 0
    }
]
```

### 3️⃣ Update User

- Method: `PUT` &nbsp;·&nbsp; URL: `http://localhost:3000/users/684f0eff17abc4e41f7cc459` &nbsp;*(the `_id` of the user to update)*
- Body:

```json
{
    "name": "Vaikunt Pai Nitte",
    "email": "vaikunt@example.com"
}
```

**Response** *(the updated document, because of `{ new: true }`)*
```json
{
    "_id": "684f0eff17abc4e41f7cc459",
    "name": "Vaikunt Pai Nitte",
    "email": "vaikunt@example.com",
    "__v": 0
}
```

### 4️⃣ Delete User

- Method: `DELETE` &nbsp;·&nbsp; URL: `http://localhost:3000/users/684f0eff17abc4e41f7cc459` &nbsp;·&nbsp; Body: not needed

**Response** *(the deleted document)*
```json
{
    "_id": "684f0eff17abc4e41f7cc459",
    "name": "Vaikunt Pai Nitte",
    "email": "vaikunt@example.com",
    "__v": 0
}
```

If the `_id` does not exist in the collection, `PUT` and `DELETE` respond with `id not found`.

## 💡 How it works

- `mongoose.connect()` opens the connection; `mongoose.model("User", schema)` gives a model with `create`, `find`, `findByIdAndUpdate`, `findByIdAndDelete`.
- `new mongoose.Schema({}, { strict: false })` is a schema **without fixed fields** – any JSON you send is stored.
- `{ new: true }` makes `findByIdAndUpdate` return the **updated** document instead of the old one.
- If the id is not found the result is `null`, and the server responds with `id not found`.


---
---

<a id="p10"></a>
# 🔐 Problem 10:
Create a simple authentication system using JSON Web Tokens (JWT). You will build the following components:

- a. A **login** route to authenticate the user and issue a JWT.
- b. A **protected** route that can only be accessed by users with a valid JWT.

---

## 🔄 How the flow works

```mermaid
sequenceDiagram
    participant C as Client (Postman)
    participant S as Express Server
    participant D as PostgreSQL
    C->>S: POST /signup  {username, password}
    S->>D: INSERT INTO clients (hashed password)
    D-->>S: row inserted
    S-->>C: 201 User registered successfully
    C->>S: POST /login  {username, password}
    S->>D: SELECT * FROM clients WHERE username=$1
    D-->>S: matching row
    S-->>C: JWT token (valid 1 hour)
    C->>S: GET /home  (Authorization: Bearer token)
    S->>S: jwt.verify(token)
    S-->>C: Welcome Authenticated User : <username>
```

## 🗃️ Step 1: PostgreSQL Table Creation

In pgAdmin, open the **Query Tool** of your database (here `MyDB`) and run:

```sql
CREATE TABLE clients (
    username VARCHAR(100) PRIMARY KEY NOT NULL,
    password VARCHAR(100) NOT NULL
);
```

> ⚠️ **Important:** Do **not** manually insert a plain-text password via SQL (`INSERT INTO clients VALUES ('student', 'student123')`), because `/login` uses `bcrypt.compare()`, which expects a **bcrypt-hashed password**. Always register users via the **`POST /signup`** endpoint first!

## 🧾 Step 2: pgdb.js

Use the **same `pgdb.js` as in Problem 7** (shown there). Make sure `database` matches the one where you created the `clients` table.

## 🧾 Step 3: 10.WebToken.js

```javascript
const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const pool = require("./pgdb");

const app = express();
app.use(express.json());

const JWT_SECRET = "anytexthere";

// Signup route
app.post('/signup', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    try {
        await pool.query('INSERT INTO clients (username, password) VALUES ($1, $2)', [username, hashedPassword]);
        res.status(201).send("User registered successfully");
    } catch {
        res.status(400).send("Username already taken or invalid");
    }
});

// Login route
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const result = await pool.query('SELECT * FROM clients WHERE username=$1', [username]);
    const user = result.rows[0];

    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.send("Unauthorized Credentials");
    }

    res.send(jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' }));
});

// Authentication middleware
const authorizeMiddleware = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.send("Invalid Authorization");

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.send(err);
        req.user = user;
        next();
    });
};

// Protected home route
app.get("/home", authorizeMiddleware, (req, res) => {
    res.send("Welcome Authenticated User : " +  req.user.username);
});

app.listen(3000, () => {
    console.log(`Server running at http://localhost:3000`);
});
```

## ▶️ : Run the Server

```bash
node 10.WebToken.js
```

## 🔗 Endpoints

| Method | URL | Auth | Purpose |
| ----- | ----- | ----- | ----- |
| `POST` | `/signup` | none | Register a new user with a hashed password |
| `POST` | `/login` | none | Verify credentials & return a JWT |
| `GET` | `/home` | `Bearer <token>` | Protected route – accessible only with a valid token |

## 🧪 Test the API Endpoints using Postman

### 1️⃣ Register a User (`/signup`)

* **Method:** `POST` &nbsp;·&nbsp; **URL:** `http://localhost:3000/signup`
* **Body** → **raw** → **JSON**:

```json
{
    "username": "student",
    "password": "student123"
}
```

**Response** — status `201 Created` *(plain text)*

```text
User registered successfully
```

If you send the same username again → `400 Bad Request`: `Username already taken or invalid`.

### 2️⃣ Login and Get the Token (`/login`)

* **Method:** `POST` &nbsp;·&nbsp; **URL:** `http://localhost:3000/login`
* **Body** → **raw** → **JSON**:

```json
{
    "username": "student",
    "password": "student123"
}
```

**Response** — status `200 OK` *(plain text – your token will be different)*

```text
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InN0dWRlbnQiLCJpYXQiOjE3NTA1OTkwMDAsImV4cCI6MTc1MDYwMjYwMH0.C_m4_xumwk0BjK51LmKmPHJbCvz4KetKeNSzc6LXBsY
```

Wrong username or password → `401 Unauthorized`: `Unauthorized Credentials`.

### 3️⃣ Access the Protected Route (`/home`)

`/home` is protected, so send the token you received from `/login`.

* **Method:** `GET` &nbsp;·&nbsp; **URL:** `http://localhost:3000/home` &nbsp;·&nbsp; **Body:** not needed
* In Postman, open the **Authorization** tab → **Type: Bearer Token** → paste the token into the **Token** box.

**Response** — status `200 OK` *(plain text)*

```text
Welcome Authenticated User : student
```

### ❌ What if the token is missing or wrong?

| Request | Status | Response |
| ----- | ----- | ----- |
| `GET /home` with no token | `401` | `Invalid Authorization` |
| `GET /home` with a wrong / tampered token | `403` | `{"name":"JsonWebTokenError","message":"jwt malformed"}` *(or `invalid signature`)* |
| `GET /home` with an expired token (after 1 h) | `403` | `{"name":"TokenExpiredError", …}` – log in again |

### 💻 Same thing with curl *(Linux / macOS / Git Bash)*

```bash
# 1. Signup
curl -X POST http://localhost:3000/signup -H "Content-Type: application/json" -d '{"username":"student","password":"student123"}'

# 2. Login
curl -X POST http://localhost:3000/login -H "Content-Type: application/json" -d '{"username":"student","password":"student123"}'

# 3. Access protected route
curl http://localhost:3000/home -H "Authorization: Bearer <paste-token-here>"
```

## 💡 How it works

* `bcrypt.hash(password, 10)` hashes the plain-text password with a salt factor of 10 before saving it to PostgreSQL, and `bcrypt.compare()` verifies it during login.
* `jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' })` creates a token carrying the username that expires in one hour (`iat` = issued-at, `exp` = expiry).
* The token has **3 parts** separated by dots: `header.payload.signature`. The signature is made with `JWT_SECRET`, so a changed token fails verification.
* `authorizeMiddleware` extracts the token from `Authorization: Bearer <token>`, verifies its signature using `jwt.verify`, attaches the decoded payload to `req.user`, and passes control via `next()`.

---
---

## 🛠️ Troubleshooting

| Problem | Fix |
| ----- | ----- |
| `Cannot find module 'express'` (or `pg`, `mongoose`, `jsonwebtoken`, `bcrypt`) | Run `npm install express pg mongoose jsonwebtoken bcrypt` in the project folder |
| `Error: listen EADDRINUSE :::3000` | Another server is still running – press **Ctrl+C** in its terminal (or close it) and start again |
| Browser shows old behaviour after editing code | Stop the server and run `node file.js` again |
| `POST` body arrives empty / `undefined` | In Postman choose **Body → raw → JSON** (not *Text*), and make sure the program has `app.use(express.json())` |
| `PUT /product` gives `404` | You forgot the id: use `/product/1` |
| `password authentication failed for user "postgres"` | Fix the password in `pgdb.js` |
| `relation "users" does not exist` | Create the table in the **same database** named in `pgdb.js` |
| `MongooseServerSelectionError … ECONNREFUSED` | Start the MongoDB service (`mongod`) first |
| `Cast to ObjectId failed` | The id in the URL is not a valid MongoDB `_id` – copy it exactly from the create response |

## 🎯 Quick Revision

### HTTP methods ↔ CRUD

| CRUD | Method | Typical URL |
| ----- | ----- | ----- |
| **C**reate | `POST` | `/users` |
| **R**ead | `GET` | `/users` |
| **U**pdate | `PUT` | `/users/:id` |
| **D**elete | `DELETE` | `/users/:id` |

### Status codes used in this lab

| Code | Meaning | Where |
| ----- | ----- | ----- |
| `200 OK` | success | most responses |
| `201 Created` | new resource created | Problem 4 `POST`, Problem 10 `/signup` |
| `400 Bad Request` | invalid input / duplicate entry | Problem 10 `/signup` |
| `401 Unauthorized` | missing or invalid credentials | Problem 10 `/login`, `/home` |
| `403 Forbidden` | invalid or expired JWT token | Problem 10 `/home` |
| `404 Not Found` | unknown URL / file | Problems 1, 2, 3, 4, 9 |

### Storage used in each CRUD program

| Program | Data is stored in | Survives restart? |
| ----- | ----- | ----- |
| 4 | `data.json` file | ✅ |
| 5 | JavaScript array | ❌ |
| 6 | `product.json` file | ✅ |
| 7 | PostgreSQL (`users` table) | ✅ |
| 8 | MongoDB (`TestDB`) | ✅ |
| 10 | PostgreSQL (`clients` table) | ✅ |

---
---

<a id="QA"></a>
# 🎓 Basic  Questions & Answers (MERN Stack & Lab Programs 1–10)

### 📌 Part A: General MERN Stack Concepts

1. **What does MERN stand for, and what is the role of each technology?**
   * **M – MongoDB:** NoSQL document-oriented database that stores data in JSON-like (BSON) documents.
   * **E – Express.js:** Lightweight backend web framework for Node.js used to build REST APIs, routing, and middleware.
   * **R – React.js:** Frontend JavaScript library for building component-based user interfaces.
   * **N – Node.js:** Server-side JavaScript runtime environment built on Chrome's V8 engine.

2. **Why is Node.js single-threaded yet able to handle thousands of concurrent requests?**
   * Node.js uses an **event-driven, non-blocking I/O model** powered by the **Event Loop** and `libuv`. Time-consuming tasks (file reads, database queries) are offloaded to the OS kernel/worker pool while the main thread continues handling incoming requests.

3. **What is the difference between `require()` (CommonJS) and `import` (ES Modules)?**
   * `require()` is synchronous and used in CommonJS (default in Node.js scripts), whereas `import` is asynchronous, statically analyzed, and part of ES6 modules (`"type": "module"` in `package.json`).

4. **What is a REST API, and how do HTTP methods map to CRUD operations?**
   * REST (Representational State Transfer) is a stateless client-server architectural style over HTTP.
   * **Create** → `POST`, **Read** → `GET`, **Update** → `PUT` (full update) / `PATCH` (partial update), **Delete** → `DELETE`.

5. **What is the difference between SQL (PostgreSQL) and NoSQL (MongoDB)?**
   * **PostgreSQL** is a relational database storing structured data in tables with fixed schemas, rows, and columns.
   * **MongoDB** is a non-relational document database storing flexible, schema-less JSON/BSON documents inside collections.

---

### 📌 Part B: Program-Specific  Questions (Programs 1–10)

6. **[Program 1 & 2] What is the difference between `Content-Type: text/plain` and `Content-Type: text/html`?**
   * `text/plain` tells the browser to display raw characters literally (showing tags like `<h1>` as text). `text/html` instructs the browser to parse and render HTML tags visually.

7. **[Program 2] What is the difference between `res.write()` and `res.end()`?**
   * `res.write()` sends a chunk of the response body while keeping the stream open for additional data; `res.end()` signals that the response is complete and closes the connection.

8. **[Program 3] Why do we need MIME types (`mimeTypes` object) when serving static files?**
   * Browsers rely on the `Content-Type` HTTP header (e.g., `text/css`, `application/javascript`) rather than just the file extension to know whether to apply CSS rules or execute JavaScript.

9. **[Program 4] Why do we read `POST` data using `req.on("data")` and `req.on("end")` in core Node.js?**
   * In Node's built-in `http` module, `req` is a **Readable Stream**. Request bodies arrive in chunks over the network, so we concatenate chunks on `"data"` and parse the complete payload once `"end"` fires.

10. **[Program 5] Why is `app.use(express.json())` required in Express POST and PUT routes?**
    * Express does not parse incoming JSON request bodies by default. `express.json()` is built-in middleware that parses JSON payloads and attaches the resulting object to `req.body`.

11. **[Program 5 vs. 6] What is the limitation of storing data in an array (Program 5) vs. a JSON file (Program 6)?**
    * An array lives in volatile RAM—all data is lost when the server stops or restarts. Writing to `product.json` persists data on disk across server restarts.

12. **[Program 7] Why do we use `$1, $2` placeholders in PostgreSQL queries (`pool.query`) instead of string concatenation?**
    * Parameterized queries prevent **SQL Injection** attacks by separating SQL logic from user-supplied data and automatically escaping values.

13. **[Program 7] What does `RETURNING *` do in PostgreSQL `INSERT`, `UPDATE`, and `DELETE` queries?**
    * By default, `INSERT`/`UPDATE`/`DELETE` only return a row count. Adding `RETURNING *` makes PostgreSQL return the affected row(s) immediately so `result.rows.length` can confirm whether a row was modified.

14. **[Program 8] What does `{ strict: false }` do in `new mongoose.Schema({}, { strict: false })`?**
    * By default, Mongoose ignores fields not defined in the schema. Setting `strict: false` allows documents with any arbitrary JSON fields to be saved into MongoDB.

15. **[Program 8] Why is `{ new: true }` passed to `User.findByIdAndUpdate()`?**
    * Without `{ new: true }`, Mongoose returns the document *before* the update was applied. Passing `{ new: true }` returns the freshly updated document.

16. **[Program 9] What is middleware in Express.js, and what happens if you forget to call `next()`?**
    * Middleware is a function with access to `(req, res, next)` that runs during the request-response cycle (e.g., logging, authentication). If `next()` is neither called nor a response sent (`res.send()`), the request hangs indefinitely and times out.

17. **[Program 9] What is the difference between global (application-level) middleware and route-level middleware?**
    * Global middleware (`app.use(...)`) executes for every incoming request across all routes, whereas route-level middleware (`app.get("/about", aboutMiddleware, ...)`) executes only when that specific route is matched.

18. **[Program 10] What are the three parts of a JWT (JSON Web Token)?**
    * `Header.Payload.Signature` separated by dots:
      1. **Header:** Token type (`JWT`) and signing algorithm (`HS256`).
      2. **Payload:** User claims/data (e.g., `username`, `iat`, `exp`).
      3. **Signature:** Cryptographic hash created using the header, payload, and `JWT_SECRET` to detect tampering.

19. **[Program 10] Why do we hash passwords using `bcrypt` before storing them in PostgreSQL?**
    * Plain-text passwords expose user accounts if the database is breached. `bcrypt.hash(password, 10)` applies a one-way cryptographic hash with 10 salt rounds, and `bcrypt.compare()` verifies login attempts safely.

20. **[HTTP Status Codes] What do `200`, `201`, `400`, `401`, `403`, and `404` signify?**
    * `200 OK`: Request succeeded.
    * `201 Created`: New resource created (`POST`).
    * `400 Bad Request`: Malformed syntax or duplicate/invalid input.
    * `401 Unauthorized`: Authentication missing or invalid login credentials.
    * `403 Forbidden`: Token invalid or expired.
    * `404 Not Found`: Requested route or resource does not exist.

---

<div align="center">

### ⭐ If this repo helped you in your lab, give it a star!

Made with ❤️ for **ISE – MERN Lab** &nbsp;|&nbsp; Happy Coding 🚀

</div>
